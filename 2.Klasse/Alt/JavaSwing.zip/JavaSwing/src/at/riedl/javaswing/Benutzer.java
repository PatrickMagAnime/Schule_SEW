
package at.riedl.javaswing;
//220227
public class Benutzer {
 public  String User;
 public  String Pwd;

//Konstruktor
public Benutzer(String User, String pwd){
    this.User = User;
    this.Pwd = pwd;

}
}