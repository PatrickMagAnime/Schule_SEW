package videosplitter.core;

// enum für video datei formate
public enum VideoFormat {
    MP4, AVI, MOV, MKV, FLV, WMV, MPEG, MPG, WEBM, M4V, VOB, OGV, MTS, M2TS, TS, F4V, MXF, RM, SWF, DIVX, UNKNOWN
}