public enum Category {
    PRIVAT, SCHULE, FREIZEIT, SONSTIGES;
}